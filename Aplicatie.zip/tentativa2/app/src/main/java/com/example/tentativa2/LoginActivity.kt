package com.example.tentativa2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    // Define your views
    private lateinit var editTextUsername: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var buttonLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize views
        editTextUsername = findViewById(R.id.editTextUsername)
        editTextPassword = findViewById(R.id.editTextPassword)
        buttonLogin = findViewById(R.id.buttonLogin)

        // Set click listener for login button
        buttonLogin.setOnClickListener {
            val username = editTextUsername.text.toString()
            val password = editTextPassword.text.toString()

            // Perform authentication (dummy check here)
            if (isValidCredentials(username, password)) {
                // Authentication successful
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()

                // Proceed to HomeActivity
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)

                // Finish the LoginActivity
                finish()
            } else {
                // Authentication failed
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Dummy authentication function
    private fun isValidCredentials(username: String, password: String): Boolean {
        // Check if username and password match some predefined values
        return username == "admin" && password == "password"
    }
}
